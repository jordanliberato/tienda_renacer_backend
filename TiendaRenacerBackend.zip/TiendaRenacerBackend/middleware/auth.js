const jwt = require('jsonwebtoken');

const auth = (req, res, next) => {
  try {
    const token = req.header('Authorization').replace('Bearer ', '');
    const decoded = jwt.verify(token, 'YOUR_SECRET_KEY'); // Reemplace 'YOUR_SECRET_KEY' con una clave secreta real
    req.userId = decoded.id;
    next();
  } catch (error) {
    res.status(401).send({ error: 'Por favor autentíquese.' });
  }
};

module.exports = auth;