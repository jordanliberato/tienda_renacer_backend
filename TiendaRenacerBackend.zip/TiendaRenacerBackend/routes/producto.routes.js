const express = require('express');
const router = express.Router();
const mysql = require('mysql2');

// Configuración de la conexión a la base de datos
const connection = mysql.createConnection({
    host: '50.87.253.191', // Reemplace con el host correcto de Bluehost
    user: 'sistemo0_jordan',
    password: 'MYjorLG26',
    database: 'sistemo0_TiendaRenacer',
    port: 3306, // Asegúrese de que este es el puerto correcto
    connectTimeout: 10000 // Aumenta el tiempo de espera a 10 segundos
  });

// GET todos los productos
router.get('/', (req, res) => {
  connection.query('SELECT * FROM productos', (error, results) => {
    if (error) return res.status(500).json({ error: error.message });
    res.json(results);
  });
});

// GET un producto específico
router.get('/:id', (req, res) => {
  connection.query('SELECT * FROM productos WHERE id = ?', [req.params.id], (error, results) => {
    if (error) return res.status(500).json({ error: error.message });
    if (results.length === 0) return res.status(404).json({ message: 'Producto no encontrado' });
    res.json(results[0]);
  });
});

// POST un nuevo producto
router.post('/', (req, res) => {
  const { nombre, costo, color, almacen, estante } = req.body;
  connection.query('INSERT INTO productos (nombre, costo, color, almacen, estante) VALUES (?, ?, ?, ?, ?)',
    [nombre, costo, color, almacen, estante],
    (error, results) => {
      if (error) return res.status(500).json({ error: error.message });
      res.status(201).json({ id: results.insertId, ...req.body });
    }
  );
});

// PUT actualizar un producto
router.put('/:id', (req, res) => {
  const { nombre, costo, color, almacen, estante } = req.body;
  connection.query('UPDATE productos SET nombre = ?, costo = ?, color = ?, almacen = ?, estante = ? WHERE id = ?',
    [nombre, costo, color, almacen, estante, req.params.id],
    (error, results) => {
      if (error) return res.status(500).json({ error: error.message });
      if (results.affectedRows === 0) return res.status(404).json({ message: 'Producto no encontrado' });
      res.json({ id: req.params.id, ...req.body });
    }
  );
});

// DELETE eliminar un producto
router.delete('/:id', (req, res) => {
  connection.query('DELETE FROM productos WHERE id = ?', [req.params.id], (error, results) => {
    if (error) return res.status(500).json({ error: error.message });
    if (results.affectedRows === 0) return res.status(404).json({ message: 'Producto no encontrado' });
    res.json({ message: 'Producto eliminado exitosamente' });
  });
});

module.exports = router;