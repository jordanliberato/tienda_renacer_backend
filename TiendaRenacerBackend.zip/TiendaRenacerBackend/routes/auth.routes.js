// routes/auth.routes.js
const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const mysql = require('mysql2/promise');

const dbConfig = {
  // ... sus detalles de conexión
};

router.post('/register', async (req, res) => {
  try {
    const connection = await mysql.createConnection(dbConfig);
    const { username, password } = req.body;
    const hashedPassword = await bcrypt.hash(password, 8);
    
    const [result] = await connection.execute(
      'INSERT INTO users (username, password) VALUES (?, ?)',
      [username, hashedPassword]
    );
    
    const token = jwt.sign({ id: result.insertId }, 'YOUR_SECRET_KEY', { expiresIn: '2h' });
    res.status(201).send({ token });
  } catch (error) {
    res.status(400).send(error);
  }
});

router.post('/login', async (req, res) => {
  try {
    const connection = await mysql.createConnection(dbConfig);
    const { username, password } = req.body;
    
    const [rows] = await connection.execute('SELECT * FROM users WHERE username = ?', [username]);
    if (rows.length === 0) {
      return res.status(400).send('Usuario o contraseña incorrectos');
    }
    
    const user = rows[0];
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).send('Usuario o contraseña incorrectos');
    }
    
    const token = jwt.sign({ id: user.id }, 'YOUR_SECRET_KEY', { expiresIn: '2h' });
    res.send({ token });
  } catch (error) {
    res.status(400).send(error);
  }
});

module.exports = router;